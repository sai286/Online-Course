package com.example.OnlineBookStore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.OnlineBookStore.model.Admin;
//import com.example.OnlineBookStore.model.User;
import com.example.OnlineBookStore.repository.AdminRepository;


@Service
public class AdminService {
	@Autowired
	private AdminRepository adrepo;
	
	public List<Admin> findAll(){
		return (List<Admin>) adrepo.findAll();
	}
	
	public boolean adminlog(String username,String password) {
		boolean log=false;
		for(Admin admin:findAll())
			
		{
			System.out.println(admin);
			if(admin.getA_user()==admin.getA_user()) {
				log=true;
				break;
			}
			System.out.println(admin.getA_pass());
			System.out.println(admin.getA_user()==username);
		}
		return log;
	}
}
