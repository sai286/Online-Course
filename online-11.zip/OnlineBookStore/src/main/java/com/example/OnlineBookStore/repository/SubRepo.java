package com.example.OnlineBookStore.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.OnlineBookStore.model.Subscribers;

public interface SubRepo extends CrudRepository<Subscribers, Integer>{

}
