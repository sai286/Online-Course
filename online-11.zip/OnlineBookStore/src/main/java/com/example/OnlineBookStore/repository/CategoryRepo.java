package com.example.OnlineBookStore.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.OnlineBookStore.model.Category;

public interface CategoryRepo extends CrudRepository<Category, Integer>{

}
