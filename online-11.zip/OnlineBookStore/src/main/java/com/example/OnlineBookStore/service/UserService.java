package com.example.OnlineBookStore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

//import com.example.OnlineBookStore.model.Admin;
import com.example.OnlineBookStore.model.User;
import com.example.OnlineBookStore.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	

	
	
	public List<User> findAll()
	{
		return (List<User>) userRepository.findAll();
	}
	
	public String isValidUser(String userName,String password)
	{
		String u=null;
		
		for(User user:findAll())
		{
			if(user.getEmail().equals(userName) && user.getPassword().equals(password))
			{
				u=user.getEmail();
				break;
			}
		}
		
		return u;
	}
	
	
	
	public boolean isExist(String username)
	{
		boolean isExist=false;
		
		for(User user:findAll())
		{
			if(user.getEmail().toLowerCase().equals(username.toLowerCase()))
			{
				isExist=true;
			}
		}
		
		return isExist;
	}
	
	
	public User getById(int id) {
		return userRepository.findById(id).get();
	}
	
	public User addNew(User user) {
		user.setPassword(user.getPassword());
//		user.setCreatedDate( new Date() );
//		user.setLastModifiedDate( user.getCreatedDate() );
//		user.setActive(1)
		return userRepository.save(user);
	}
	
	public User update(User user) {
//		user.setLastModifiedDate( new Date() );
		return userRepository.save( user );
	}
	
	public void delete(User user) {
		userRepository.delete(user);
	}
	
	public void delete(int id) {
		userRepository.deleteById(id);
	}
}
