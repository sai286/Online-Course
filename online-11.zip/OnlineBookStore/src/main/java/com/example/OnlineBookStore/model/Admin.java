package com.example.OnlineBookStore.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

//import org.springframework.stereotype.Controller;

@Entity
public class Admin {
	
	@Id
	@GeneratedValue
	private String id;
	private String a_user;
	private String a_pass;
	public String getA_user() {
		return a_user;
	}
	public void setA_user(String a_user) {
		this.a_user = a_user;
	}
	public String getA_pass() {
		return a_pass;
	}
	public void setA_pass(String a_pass) {
		this.a_pass = a_pass;
	}
	@Override
	public String toString() {
		return "Admin [a_user=" + a_user + ", a_pass=" + a_pass + "]";
	}
	
}
