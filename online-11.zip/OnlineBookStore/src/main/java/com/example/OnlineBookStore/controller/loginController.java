package com.example.OnlineBookStore.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.OnlineBookStore.model.Category;
import com.example.OnlineBookStore.model.Checkout;
import com.example.OnlineBookStore.model.Subscribers;
import com.example.OnlineBookStore.model.User;
import com.example.OnlineBookStore.repository.CategoryRepo;
import com.example.OnlineBookStore.repository.CheckoutRepository;
import com.example.OnlineBookStore.repository.CourseRepository;
import com.example.OnlineBookStore.repository.SubRepo;
import com.example.OnlineBookStore.repository.UserRepository;
import com.example.OnlineBookStore.service.AdminService;
import com.example.OnlineBookStore.service.UserService;


@Repository
@Controller
public class loginController {
	
	@Autowired
	UserRepository urepo;
	
	@Autowired
	UserService userservice;
	
	@Autowired
	SubRepo sub;
	
	@Autowired
	CheckoutRepository check;
	
	@Autowired
	AdminService admin;
	
	@Autowired
	CourseRepository adrep;
	
	@Autowired
	CategoryRepo catrepo;
	
	@Autowired
	CheckoutRepository CheckoutRepository;
	
	@GetMapping("/")
	public String home()
	{
		return "/login";
	}
	
	
	@GetMapping("/login")
	public String getLogin()
	{
		return "/login";
	}
	
	@GetMapping("/admin_home")
	public String getin()
	{
		return "/admin_home";
	}
	
	@PostMapping(value = "/register")
	public String regAction(@ModelAttribute User user, Model model)
	{
		System.out.println(user);
		if(!userservice.isExist(user.getEmail()))
		{
			//user.setRole("user");
			urepo.save(user);
			model.addAttribute("message","Registred Successfully");
			return "/home";
		}
		else
		{
			model.addAttribute("message","User Already Exist");
			return "/Registration";
		}
	}
	
//	
//	  @PostMapping("/login") public ModelAndView log(@RequestParam("u") String
//	  user,@RequestParam("p") String pass ) { ModelAndView mv = new ModelAndView(); User
//	  list=urepo.findByEMAIL(user); if(user==list.getEmail()&&
//	  pass==list.getPassword()) { System.out.println(list.getEmail());
//	  mv.setViewName("home"); } else { System.out.println(list.getPassword());
//	  mv.setViewName("login"); } return mv; }
	 
	
	/*
	 * @PostMapping("/addUser") public ModelAndView
	 * addUser(@RequestParam("user_email") String user_email, User user) {
	 * ModelAndView mv=new ModelAndView("success"); List<User>
	 * list=urepo.findByEMAIL(user_email);
	 * 
	 * if(list.size()!=0) { mv.addObject("message",
	 * "Oops!  There is already a user registered with the email provided.");
	 * 
	 * } else { urepo.save(user);
	 * mv.addObject("message","User has been successfully registered."); }
	 * 
	 * return mv; }
	 */
	
	
	
	  @PostMapping("/login") 
	  public String login_user(@RequestParam("u") String username,@RequestParam("p") String password, HttpSession session,ModelMap
	  modelMap) {
	 	  
	  System.out.println(userservice.isValidUser(username, password));
	  
		  if(userservice.isValidUser(username, password)!=null) {
			  session.setAttribute("username",username);
			  System.out.println("succ");
			  List<Category> categ=(List<Category>) catrepo.findAll();
				session.setAttribute("List", categ);
			  
				
				
			  return "/home"; 
		  } 
		  else {
			  modelMap.put("error", "Invalid Account"); 
			  System.out.println("int");
			  return "/login"; 
		  } 
	  }
	  
	  
	  @GetMapping(value="/registered_users")
	  public String reguser(HttpSession session) {
		  List<User> list=userservice.findAll();
		  //System.out.println(list);
		  session.setAttribute("useritem", list);
		  return "/registered_users";
	  }
	  
	  @GetMapping(value = "/Subscribers")
	  public String subs(HttpSession session) {
		  List<Checkout> list=(List<Checkout>) check.findAll();
		  System.out.println(list);
		  
		  session.setAttribute("useritem", list);
		  return "/Subscribers";
	  }
	  
	  @PostMapping(value="/admin_login")
	  public ModelAndView adminlog(@RequestParam("u") String username,@RequestParam("p") String password, HttpSession session,ModelMap
			  modelMap)
	  {
		  ModelAndView mv = new ModelAndView();
		  if(admin.adminlog(username, password)) {
			  
			  mv.setViewName("/admin_home");
		  }else {
			  //System.out.println(userservice.adminlog(username, password));
			  System.out.println(password);
			  mv.addObject("error", "Invalid Credentials");
			  mv.setViewName("/adminlog");
		  }
		  
		  return mv;
	  }
	 
	 @GetMapping(value="/delete_user")
	 public String deluser(HttpSession session, @ModelAttribute User user) {
		 System.out.println(user);
		 userservice.delete(user.getId());
		 //session.setAttribute("deleted_user", "User Deleted");
		 return "/admin_home";
	 }
	 
	
	@GetMapping(value = "/logout")
	public String logout_user(HttpSession session)
	{
		session.removeAttribute("username");
		session.invalidate();
		return "redirect:/login";
	}
	
}
